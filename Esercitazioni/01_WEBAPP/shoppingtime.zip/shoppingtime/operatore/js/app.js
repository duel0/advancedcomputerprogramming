var order_update = 0;  // order_update track if orders were added by clients to PENDING

var main = function (orderObjects) {

    "use strict";

    $(".tabs a span").toArray().forEach(function (element) {
        var $element = $(element);

        // create a click handler for this element
        $element.on("click", function () {
        
            $(".tabs a span").removeClass("active");
            $element.addClass("active");
            $("main .content").empty();


            // comportamento tabs
            // PENDING ORDERS
            // Mostra tutti gli ordini fatti dal cliente e permette di cambiare stato a COMPLETED o REJECTED, aggiornando il DB
            

            if ($element.parent().is(":nth-child(1)")) {
                var $content;            
                
                var  $button_complete = $("<span>").text("Complete"),
                     $button_reject = $("<span>").text("Reject"),
                     selected_order_ID;


                // TO BE COMPLETED....PENDING
                // render the list of all orders which are not completed or rejected

                // GET /orders?status=PENDING
                $.getJSON("/orders", {"status":"PENDING"}, function (orders){
                    console.log("1st tab clicked orders: ", orders);
                    if (orders.length > 0){
                        $content = $("<ul>");
                        
                        orders.forEach(function (order){
                            console.log("order id: " + order.id + " status: " + order.status);
                            // mi costruisco la lista unordered con i vari list item degli ordini PENDING
                            // mettendomi order.id nell'attributo order_id 
                            $content.append($('<li order_id="' + order.id + '">' ).text("ID: " + order.id + " status: " + order.status));
                            
                        });
                        $content.append("<div>").append($button_complete, $button_reject);

                        $("main .content").append($content);
                        
                        // add listener su ul per prendersi il <li> con ID specifico
                        document.querySelector('ul').addEventListener('click', function(e) { 
                            var selected;
                            // check if tag name is <li>...note LI needs to be capitalize
                            if(e.target.tagName === 'LI') {                                      
                                selected = document.querySelector('li.selected');                  
                                console.log("li.selected is ", selected); 
                                if(selected){ //check last <li> is selected and erase class selected
                                    selected.className= '';                               
                                }
                                // update class for current event e 
                                e.target.className= 'selected';                                   
                                selected_order_ID = e.target.getAttribute('order_id') 
                                console.log("click <li> order_id = ", e.target.getAttribute('order_id'));
                            }
                        });
                        

                    } else {
                        $("main .content").append("<h2>No pending orders</h2>"); 
                    }
                });
  
                var update_order_status = function (order_id, order_status){
                    // built order to update with status REJECTED
                    var order_to_update = {"id":order_id, "status": order_status};

                    // send PUT /order/status ?status=REJECTED or PUT /order/status ?status=COMPLETED
                    $.ajax({

                        url: '/order/status',
                        type:'PUT',
                        data: order_to_update,
                        success: function(result){
                            console.log(result);
                        }
                    });

                    // reset notify span 
                    $(".notify span").text("");

                };
                
                // Add listener on Complete button click
                $button_reject.on("click", function(){

                    console.log("Clicked button reject");
                    console.log("selected order ID: ", selected_order_ID);
                    if (selected_order_ID){
                        update_order_status(selected_order_ID, "REJECTED");
                        order_update--;
                    } else {
                        alert("Please, select an order");
                    }
                    
                    $(".tabs a:first-child span").trigger("click");
                });

                // Add listener on Complete button touch
                $button_reject.on("touchstart", function(){

                    console.log("touchstart button reject");
                    console.log("selected order ID: ", selected_order_ID);
                    if (selected_order_ID){
                        update_order_status(selected_order_ID, "REJECTED");
                        order_update--;
                    } else {
                        alert("Please, select an order");
                    }
                    
                    $(".tabs a:first-child span").trigger("click");
                });

                // Add listener on Reject button click
                $button_complete.on("click", function () {

                    console.log("Clicked button complete");
                    if (selected_order_ID){
                        update_order_status(selected_order_ID, "COMPLETED");
                        order_update--;
                    } else{
                        alert("Please, select an order");
                    }
                    $(".tabs a:first-child span").trigger("click");
                });

                // Add listener on Reject button touch
                $button_complete.on("touchstart", function () {

                    console.log("Clicked button complete");
                    if (selected_order_ID){
                        update_order_status(selected_order_ID, "COMPLETED");
                        order_update--;
                    } else{
                        alert("Please, select an order");
                    }
                    $(".tabs a:first-child span").trigger("click");
                });

                 
            }

            // Completed ORDERS
            // Mostra tutti gli ordini che sono nello stato di COMPLETED
            else if ($element.parent().is(":nth-child(2)")) {

                $content = $("<p>");
                
                $.getJSON("/orders", {"status":"COMPLETED"}, function(orderObjects){

                    orderObjects.forEach(function (order){
                        
                        $content.append($("<h3>").text("ORDER ID: " + order.id));
                        $content.append($("<ul>"));
                        
                        order.products.forEach(function (product){
                            $content.append($("<li>").text(product.name + " - " + product.quantity));
                        });

                    });
                });
                 
            }

            console.log("content to add to main" + $content)
            $("main .content").append($content);

            return false;
        });
    });

    $(".tabs a:first-child span").trigger("click");
};

var check_order_update= function (first){
    
    $.getJSON("/orders", {"status":"PENDING"}, function(orderObjects){

        console.log("EXECUTED - get= " + orderObjects.length + " order_update= " + order_update);
        if (first)
            order_update = orderObjects.length;
        else if ( order_update != orderObjects.length ){
            $(".notify span").text("Orders state changed. Check the \"Pending Orders\" tab");
            order_update = orderObjects.length;
            $(".tabs a:first-child span").trigger("click");
        }

    });

}

// When the document is loaded
$(document).ready(function () {

    check_order_update(true);   // Set the counter of PENDING orders for order_update
    main();                     // Call the main function

});

// Periodically check if orders change their status
setInterval(function(){check_order_update(false)}, 1000);
