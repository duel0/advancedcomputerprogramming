var order_update = 0;  // order_update tracks if the status of orders were modified by the operator


var main = function () {

    "use strict";

    // Remove notification string
    $(".notify span").on("click", function(){

        $(".notify span").text("");

    });

    $(".tabs a span").toArray().forEach(function (element) {
        var $element = $(element);

        // create a click handler for this element
        $element.on("click", function () {
            var $content;

            $(".tabs a span").removeClass("active");
            $element.addClass("active");
            $("main .content").empty();

            if ($element.parent().is(":nth-child(1)")) { // "Orders" tab: Shows all the orders made by the client

                
                
                $content = $("<p>");

                // Ask to the server the list of orders made by the client
                $.getJSON("/orders", function(orderObjects){

                    console.log("orderObjects: " + orderObjects);
                    // Iterate on the orders list
                    orderObjects.forEach(function (order){
                        
                        // Show the id and status of each order
                        $content.append($("<h3>").text("ORDER ID: " + order.id));
                        $content.append($("<h4 class=" + order.status.toString().toLowerCase() + ">").text("STATUS: " + order.status));

                        $content.append($("<ul>"));
                        
                        // Iterate on the list of products composing the order
                        order.products.forEach(function (product){

                            //Show the name and quantity of each product
                            $content.append($("<li>").text(product.name + " - " + product.quantity));
                        });

                    });
                });

            } else if ($element.parent().is(":nth-child(2)")) { // "Add product" tab: Allows the client to add a product to the cart
                
                var $nameInput = $("<input>").addClass("product_name"),
                    $nameLabel = $("<p>").text("Product name: "),
                    $quantityInput = $("<input>").addClass("quantity"),
                    $quantityLabel = $("<p>").text("Quantity: "),
                    $button = $("<span>").text("Add to cart");

                $button.on("click", function () {
                    var product_name = $nameInput.val(),
                        quantity = $quantityInput.val(),
                        order,
                        newProduct = {"name":product_name, "quantity":quantity};

                        newProduct = [

                            {"name":old_n, "quantity":old_q},
                            {"name":product_name, "quantity":quantity}
                        ]

                    if (product_name!=="" && quantity!=""){


                        // Retrieve from the server all the products in the cart, i.e., all the orders with status == "CART"
                        $.getJSON("/orders", {"status":"CART"}, function (cart){

                            // If the cart exists, add the new product to the cart
                            if (cart.length != 0){

                                // Get the list of product from the cart, and add the new product
                                cart[0].products.push(newProduct);
                                order = cart[0];

                                // Perform an HTTP PUT to update the cart on the server
                                $.ajax({

                                        url: '/order/products',
                                        type:'PUT',
                                        data: order,
                                        success: function(result){

                                            console.log(result);

                                        }

                                });

                            } else {    // If the cart does not exist, create the cart, i.e., an order with STATUS == "CART"
                            
                                order = {"id":-1, "status":"CART", "products":newProduct};

                                // Make an HTTP POST to create the new order
                                $.post("/order", order, function (result) {

                                    console.log(result);
    
                                });
                            }

                        });

                        $nameInput.val("");
                        $quantityInput.val("");
                        
                    } else {

                        alert("Please, add product name and desired quantity to be ordered!");

                    }

                });

                $content = $("<div>").append($nameLabel)
                                     .append($nameInput)
                                     .append($quantityLabel)
                                     .append($quantityInput)
                                     .append($button);

                


            } else if ($element.parent().is(":nth-child(3)")) { // "Cart" tab: Shows all the products in the cart, allowing to submit the order

                $content = $("<ul class=\"cart\">");
                $content.append($("<li>").text("No products in the cart"));

                // Retrieve from the server all the products in the cart, i.e., all the orders with status == "CART"
                $.getJSON("/orders", {"status":"CART"}, function (cart){

                    if (cart.length > 0){

                        $(".cart").empty();

                        // Show the products in the cart
                        cart[0].products.forEach(function (product){

                            $content.append($("<li>").text(product.name + " - " + product.quantity));

                        });

                        // Create the button to make the order
                        var $button_cart = $("<span>").text("Make order");

                        // When the button is pressed, change the status of the order in "PENDING"
                        $button_cart.on("click", function () {

                            cart[0].status = "PENDING";

                            // Perform an HTTP PUT to update the order on the server
                            $.ajax({
        
                                url: '/order/status',
                                type:'PUT',
                                data: cart[0],
                                success: function(result){
        
                                    console.log(result);

                                    // Empty the "CART" tab
                                    $(".cart").empty();
                                    $(".cart").append($("<li>").text("No products in the cart"));

                                    order_update++;


        
                                }
                            });
        
                        });

                        $content.append($button_cart);

                    }

                });

            }

            $("main .content").append($content);

            return false;
        });
    });

    $(".tabs a:first-child span").trigger("click");
};

// Check the order_update counter in order to notify the client if the status of an order were modified by the operator
var check_order_update= function (first){
    
    // Retrieve the list of orders in PENDING status
    $.getJSON("/orders",  {"status":"PENDING"}, function(orderObjects){

        // if it is the first ecxecution set the order_update counter
        if (first)
            order_update = orderObjects.length;
        else if ( order_update != orderObjects.length ){ // otherwise check the difference between the previous amount of PENDING orders (i.e., order_update) and the current one (i.e., orderObjects.length)
            $(".notify span").text("Products updated: "+ (order_update - orderObjects.length) + "! Check the Orders tab");
            order_update = orderObjects.length;
            $(".tabs a:first-child span").trigger("click");
        }
        

    });

}

// When the document is loaded
$(document).ready(function () {

    check_order_update(true);  // Set the counter of PENDING orders
    main();                     // Call the main function

});

// Periodically check if orders change their status
setInterval(function(){check_order_update(false)}, 1000);
