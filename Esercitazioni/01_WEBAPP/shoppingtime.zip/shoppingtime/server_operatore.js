var express = require("express"),
    http = require("http"),
    mongoose = require("mongoose"),
    app = express(),
	id = 0;

app.use(express.static(__dirname + "/operatore"));

app.use(express.urlencoded());

mongoose.connect('mongodb://localhost/shoppingtime');

var OrderSchema = mongoose.Schema({    
    id: Number,
	status: {
		type: [String],
		enum : ["CART", "PENDING", "COMPLETED", "REJECTED"],
		default: 'CART'
	},
	products: [ {name: String, quantity: Number} ]

});

var Order = mongoose.model("Order", OrderSchema);

http.createServer(app).listen(3002);

console.log("Server Operatore creato, listen on port 3002");

// GET /orders?status=PENDING

/* 
	GET /orders?status=PENDING ritorna la lista degli ordini nello stato PENDING
*/

app.get("/orders", function (req, res) {
    	
	console.log("/orders invoked with status: " + req.query.status);

	Order.find({"status": req.query.status}, function (err, orders) {
		console.log(orders);
		res.json(orders);
    });
});


// send PUT /order/status ?status=XXX

/* 
	PUT /order/status ?status=XXX deve permettere di aggiornare lo stato di un ordine a partire dal suo ID
*/

app.put("/order/status", function (req, res) {

	var order_id = req.body.id;
	var order_status = req.body.status;
	
	Order.find({"id": order_id}, function (err, order) {
		order.forEach(element => {
			
			// update status
			element.status = order_status;

			// update order with save to trigger schema validation
			element.save(function (err) {
				if (err){
					console.log(err)
					res.send("ERROR");
				}
				else{
					console.log("Updated order ID: " +  order_id + " with status : " + order_status);
					res.send({"message": "ORDER UPDATED"});
				}
				
			});
		});
		
		
    });
});
