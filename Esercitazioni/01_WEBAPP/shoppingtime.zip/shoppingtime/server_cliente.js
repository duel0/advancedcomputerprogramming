var express = require("express"),
    http = require("http"),
    mongoose = require("mongoose"),
    app = express(),
	id = 0;

app.use(express.static(__dirname + "/client"));

app.use(express.urlencoded());

mongoose.connect('mongodb://localhost/shoppingtime');


var OrderSchema = mongoose.Schema({    
    id: Number,
	status: {
		type: [String],
		enum : ["CART", "PENDING", "COMPLETED", "REJECTED"],
		default: 'CART'
	},
	products: [ {name: String, quantity: Number} ]

});

var Order = mongoose.model("Order", OrderSchema);

// Get the list of orders and identify the maximum id
// The maximun id will be used to generate the id for new orders 
Order.find({}, function (err, result){

	var max = -1;
	result.forEach(element => {
		if (element.id > max)
			max = element.id;
	});

	id = max;
	console.log("MAX = " + max);

});

http.createServer(app).listen(3000);


// GET /orders?status=STATUS

/* 
	GET /orders?status=STATUS ritorna la lista degli ordini nello stato STATUS
*/

app.get("/orders", function (req, res) {
    	
	filter = req.query.status != null ? {"status": req.query.status} : {};
	
	Order.find(filter, function (err, orders) {
		console.log(orders);
		res.json(orders);
    	});
});

// POST /order

/* 
	POST /order permette di creare un nuovo ordine nello stato fornito nel body con la lista di prodotti scelta
*/

app.post("/order", function (req, res) {
    
	console.log(req.body);

	var newOrder = new Order({"id":++id, "status":req.body.status, "products":req.body.products});

	newOrder.save(function (err, result) {
		if (err !== null) {
			
			console.log(err);
			res.send("ERROR");

		} else {
			
			Order.find({}, function (err, result) {
				
				if (err !== null) {
			    		
					console.log(err);
			    	res.send("ERROR");
				}
			
				res.json(result);
			});
		}
	});
});

// send PUT /order/status ?status=XXX

/* 
	PUT /order/status ?status=XXX deve permettere di aggiornare lo stato di un ordine a partire dal suo ID
*/

app.put("/order/status", function (req, res) {

	var order_id = req.body.id;
	var order_status = req.body.status;
	
	Order.find({"id": order_id}, function (err, order) {
		order.forEach(element => {
			
			// update status
			element.status = order_status;

			// update order with .save to trigger schema validation
			element.save(function (err) {
				if (err){
					console.log(err)
					res.send("ERROR");
				}
				else{
					console.log("Updated order ID: " +  order_id + " with status : " + order_status);
					res.send({"message": "ORDER UPDATED"});
				}
				
			});
		});
		
		
    });
	/*
	Order.updateOne({"id":req.body.id}, {"status":req.body.status}, function (err, docs) {
		if (err){
			console.log(err)
			res.send("ERROR");
		}
		else{
			console.log("Updated Docs : ", docs);
			res.send({"message": "ORDER UPDATED"});
		}
		
	});
	*/
});

/*  
	PUT /order/products ?products=[{"name":product_name, "quantity":quantity}, ...];
	Permette di aggiornare la lista dei prodotti per un dato ordine ancora da inviare
*/

app.put("/order/products", function (req, res) {

	var order_id = req.body.id;
	var order_products = req.body.products;
	
	Order.find({"id": order_id}, function (err, order) {
		order.forEach(element => {
			
			// update products
			element.products = order_products;

			// update order with .save to trigger schema validation
			element.save(function (err) {
				if (err){
					console.log(err)
					res.send("ERROR");
				}
				else{
					console.log("Updated order ID: " +  order_id + " with products : " + order_products);
					res.send({"message": "ORDER UPDATED"});
				}
				
			});
		});
		
		
    });
	/*
	Order.updateOne({"id":req.body.id}, {"products":req.body.products}, function (err, docs) {
		if (err){
			console.log(err)
			res.send("ERROR");
		}
		else{
			console.log("Updated Docs : ", docs);
			res.send({"message": "ORDER UPDATED"});
		}
		
	});
	*/
});
