package coda;

public interface Coda {
	
	public void inserisci( int i);
	public int preleva();
	public boolean empty();
	public boolean full();
	public int getSize();
}
